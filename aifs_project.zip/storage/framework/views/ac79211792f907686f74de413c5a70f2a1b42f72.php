
<?php $__env->startSection('main-container'); ?>

<!-- Page-header start -->
<div class="page-header">
    <div class="page-block">
        <div class="row align-items-center">
            <div class="col-md-8">
                <div class="page-header-title">
                    <h5 class="m-b-10">Agent</h5>
                    <p class="m-b-0">Show All Agent Data Table</p>
                </div>
            </div>
            <div class="col-md-4">
                <ul class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(url('dashboard')); ?>"> <i class="fa fa-home"></i> </a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Agent</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Page-header end -->
<div class="container mt-2 mb-2">
    <a href="<?php echo e(url('admin/add-agent')); ?>" class="btn btn-success btn-sm waves-effect waves-light float-md-right"> <i class="fa fa-plus" aria-hidden="true"></i>Agent Register</a>
</div>
<br>
<div class="container card mt-lg-4">
    <?php if($msg = Session::get('msg')): ?>
    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e($msg); ?></strong>
    </div>

    <?php elseif($deleteMsg = Session::get('deleteMsg')): ?>
    <div class="alert alert-danger alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e($deleteMsg); ?></strong>
    </div>
    <?php elseif(Session::get('faild')): ?>
    <div class="alert alert-danger alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e(Session::get('faild')); ?></strong>
    </div>
    <?php endif; ?>
    <div class="shadow p-3 mb-5 bg-white rounded">
        <table id="example" class="display nowrap table table-bordered table-striped text-center" style="width:100%">
            <thead>
                <tr>
                    <th>S.No.</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Action</th>

                </tr>
            </thead>
            <tbody>
                <!-- <?php echo e($i=1); ?> -->
                <?php $__currentLoopData = $agent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agentData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <!-- <td><?php echo e($agentData['image']); ?></td> -->
                    <td>
                        <img src="<?php echo e(asset('agent_img/'.$agentData->image)); ?>" width="100" height="100" alt="image">
                    </td>

                    <td><?php echo e($agentData['name']); ?></td>
                    <td><?php echo e($agentData['email']); ?></td>
                    <td>
                    <?php if($agentData->type == 0): ?>
                      <span class="badge badge-success">Admin</span>
                      <?php else: ?>
                      <span class="badge badge-primary">Agent</span>
                      <?php endif; ?>
                    </td>
                    <td>
                    <?php if($agentData->status == 1): ?>
                      <a href="<?php echo e(url('agent-block')); ?>/<?php echo e($agentData->id); ?>" onclick="return confirm('Are You Sure Block This Agent.')"><span class="badge badge-success">Active</span></a>
                      <?php else: ?>
                      <a href="<?php echo e(url('agent-active')); ?>/<?php echo e($agentData->id); ?>" onclick="return confirm('Are You Sure Active This Agent.')"><span class="badge badge-danger">Block</span></a>
                      <?php endif; ?>
                    </td>
                    <td>
                        <button type="button" class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>
                        <div class="dropdown-menu">
                            <!-- <a class="dropdown-item" href="#">Action</a> -->
                            <a class="dropdown-item" href="<?php echo e(url('admin/edit-agent')); ?>/<?php echo e($agentData->id); ?>">Edit</a>

                            <a class="dropdown-item" href="<?php echo e(url('admin/delete-agent')); ?>/<?php echo e($agentData->id); ?>" onclick="return confirm('Are You sure Delete this Agent')">Delete</a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\xampp\htdocs\aifs_project\resources\views/admin/agent.blade.php ENDPATH**/ ?>